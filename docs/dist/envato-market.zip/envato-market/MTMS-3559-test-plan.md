# MTMS-3559 Test Plan — PHP 8.4 Compatibility & v2.0.13 Release

## Overview

Verify the Envato Market plugin (v2.0.13) functions correctly on PHP 8.4 with no deprecation warnings or fatal errors. All core user flows must pass before the release is published.

---

## Environment Setup

### Start the PHP 8.4 test environment

```bash
docker compose pull        # pull wordpress:6.7-php8.4-apache
docker compose up -d
```

Wait ~30 seconds for the database to be ready, then visit **http://localhost:8080**.

WordPress should auto-install (via the `wpcli` service) with:
- URL: `http://localhost:8080`
- Admin user: `dev` / Password: `dev`

> **Enable debug log:** The environment sets `WP_DEBUG=true` and `WP_DEBUG_LOG=true` by default. Tail the log during testing:
> ```bash
> docker compose exec wordpress tail -f /var/www/html/wp-content/debug.log
> ```

### Install the plugin

Because `./` is mounted at `wp-content/plugins/envato-market/`, the plugin is already present. Activate it:

1. Log in to **http://localhost:8080/wp-admin**
2. Go to **Plugins → Installed Plugins**
3. Activate **Envato Market**

---

## PHP 8.4 Checks (run throughout all flows)

After every action, check:

- [ ] No `PHP Deprecated:` lines in `wp-content/debug.log`
- [ ] No `PHP Fatal error:` lines in `wp-content/debug.log`
- [ ] No `PHP Warning:` lines introduced by the plugin code (framework warnings are acceptable)
- [ ] No `PHP Notice:` lines from plugin code

---

## Test Cases

### TC-01 — PHP 8.4 Deprecation Notice

**Purpose:** Verify the plugin shows the PHP deprecation notice for sites that would be running PHP < 8.2 (this test is on 8.4, so the notice must NOT appear).

**Steps:**
1. Navigate to any admin page after activating the plugin
2. Check the admin notice area at the top of the page

**Expected:** No deprecation notice about PHP versions below 8.2 (since PHP 8.4 ≥ 8.2).

---

### TC-02 — Plugin Activation & Options Initialisation

**Purpose:** Confirm the plugin activates cleanly and registers its options.

**Steps:**
1. Deactivate then re-activate the plugin from **Plugins → Installed Plugins**
2. Check the debug log for errors

**Expected:**
- [ ] Plugin activates with no errors in the log
- [ ] **Envato Market** menu item appears in the WP admin sidebar

---

### TC-03 — Admin Page Loads

**Purpose:** Confirm all admin tabs render without PHP errors.

**Steps:**
1. Go to **Envato Market** in the sidebar
2. Click through each tab: **Settings**, **Themes**, **Plugins**, **Help**

**Expected:**
- [ ] Each tab renders without a white screen or PHP error
- [ ] No errors added to debug.log
- [ ] Settings panel shows the OAuth token field
- [ ] Themes and Plugins tabs show empty states (no items yet)

---

### TC-04 — API Token Authorization

**Purpose:** Verify the token entry, validation, and permissions check flow.

**Prerequisites:** A valid Envato personal token from https://build.envato.com/create-token/ with scopes: `View and search Envato sites`, `Download your purchased items`, `List purchases`.

**Steps:**
1. Go to **Envato Market → Settings**
2. Enter a valid API token in the **Personal Token** field
3. Click **Save Changes**

**Expected:**
- [ ] Success notice displayed: "Your token was authorized and your items were updated."
- [ ] No PHP errors in debug.log
- [ ] Purchased themes appear under the **Themes** tab
- [ ] Purchased plugins appear under the **Plugins** tab

**Also test with an invalid token:**
1. Enter a random invalid string as the token
2. Click **Save Changes**

**Expected:**
- [ ] Error notice displayed
- [ ] No fatal errors in debug.log

---

### TC-05 — Themes Tab: Install a Theme

**Purpose:** Verify theme installation works on PHP 8.4.

**Prerequisites:** TC-04 passed with a valid token; at least one purchased theme is visible.

**Steps:**
1. Go to **Envato Market → Themes**
2. Click **Install** on any listed theme
3. Wait for installation to complete
4. Click **Activate** on the newly installed theme

**Expected:**
- [ ] Installation progress screen shows without PHP errors
- [ ] Theme installs successfully
- [ ] Theme can be activated
- [ ] No errors in debug.log

---

### TC-06 — Plugins Tab: Install a Plugin

**Purpose:** Verify plugin installation works on PHP 8.4.

**Prerequisites:** TC-04 passed with a valid token; at least one purchased plugin is visible.

**Steps:**
1. Go to **Envato Market → Plugins**
2. Click **Install** on any listed plugin
3. Wait for installation to complete
4. Activate the installed plugin

**Expected:**
- [ ] Installation completes without PHP errors
- [ ] Plugin activates without errors
- [ ] No errors in debug.log

---

### TC-07 — Update Detection

**Purpose:** Verify the update check mechanism works on PHP 8.4.

**Steps:**
1. With a valid token and at least one installed theme or plugin, go to **Dashboard → Updates**
2. Click **Check Again**

**Expected:**
- [ ] Page loads without PHP errors
- [ ] If a newer version exists, it appears in the update list
- [ ] No errors in debug.log

---

### TC-08 — Health Check (AJAX)

**Purpose:** Verify the AJAX health check works on PHP 8.4.

**Steps:**
1. Go to **Envato Market → Help**
2. Click **Run Health Check** (or equivalent button in the Help panel)

**Expected:**
- [ ] Health check results display
- [ ] Server memory limit, PHP version, WordPress version shown
- [ ] PHP version shown as 8.4.x
- [ ] No JS console errors; no PHP errors in debug.log

---

### TC-09 — Deferred Download

**Purpose:** Verify the deferred download/update URL generation works.

**Steps:**
1. In **Envato Market → Themes** or **Plugins**, check that installed items show an **Update** button if an update is available
2. Trigger an update for an installed item

**Expected:**
- [ ] Update process starts and completes without errors
- [ ] No `PHP Deprecated` or fatal errors in debug.log

---

### TC-10 — Transient Clearing

**Purpose:** Verify cache clearing does not break on PHP 8.4.

**Steps:**
1. Go to **Envato Market → Settings**
2. Re-save settings (triggers `maybe_delete_transients()`)

**Expected:**
- [ ] Transients cleared without errors
- [ ] Page reloads and items are re-fetched from the API

---

### TC-11 — PHP Version Shown in Help / Health Check

**Purpose:** Confirm PHP 8.4 is detected and shown correctly.

**Steps:**
1. Go to **Envato Market → Help**
2. Run the health check and inspect the PHP version field

**Expected:**
- [ ] PHP version field displays `8.4.x`

---

## Teardown

```bash
docker compose down
```

---

## Acceptance Criteria (from ticket)

| Criterion | Status |
|-----------|--------|
| Docker environment running PHP 8.4 | ☐ |
| Plugin verified working on PHP 8.4 (all TCs pass) | ☐ |
| No PHP 8.4 deprecation warnings or fatal errors in debug.log | ☐ |
| `update-check.json` updated to v2.0.13 / WP 6.7 | ☐ |
| `grunt deploy` run to rebuild `docs/dist/envato-market.zip` | ☐ |
| v2.0.13 git tag and GitHub Release created | ☐ |
| https://www.envato.com/lp/market-plugin/ serves v2.0.13 | ☐ |
